@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if not exist "%CSC%" (
    echo ERROR: C# compiler not found.
    exit /b 1
)

if not exist "ScHideHook.cs" (
    echo ERROR: ScHideHook.cs not found.
    exit /b 1
)

set "NEED_BUILD=0"
if not exist "ScHide.exe" set "NEED_BUILD=1"

if "%NEED_BUILD%"=="0" (
    powershell -NoProfile -Command "if ((Get-Item '%~dp0ScHideHook.cs').LastWriteTime -gt (Get-Item '%~dp0ScHide.exe').LastWriteTime) { exit 1 } else { exit 0 }"
    if errorlevel 1 set "NEED_BUILD=1"
)

if "%NEED_BUILD%"=="1" (
    echo Building ScHide.exe...
    "%CSC%" /nologo /optimize+ /target:winexe /out:"%~dp0ScHide.exe" /r:System.Windows.Forms.dll /r:System.Management.dll "%~dp0ScHideHook.cs"
    if errorlevel 1 (
        echo ERROR: Build failed.
        exit /b 1
    )
)

tasklist /FI "IMAGENAME eq ScHide.exe" 2>nul | find /I "ScHide.exe" >nul
if not errorlevel 1 exit /b 0

start "" /B "%~dp0ScHide.exe"
exit /b 0
