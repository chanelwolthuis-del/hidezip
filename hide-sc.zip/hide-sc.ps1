# ScreenConnect UI Hider - runs forever (no .exe, works with App Control policies)
$ScInstallDir = 'C:\Program Files (x86)\ScreenConnect Client (fd944d6092d0e488)'

$mutex = New-Object System.Threading.Mutex($false, 'Local\ScHidePowerShell')
if (-not $mutex.WaitOne(0, $false)) { exit 0 }

if (-not ([System.Management.Automation.PSTypeName]'ScWin32').Type) {
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class ScWin32 {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
    [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hWnd, int attr, ref int val, int size);
    public const int GWL_EXSTYLE = -20;
    public const int WS_EX_TOOLWINDOW = 0x80;
    public const int WS_EX_APPWINDOW = 0x40000;
    public const int SW_HIDE = 0;
    public const int DWMWA_CLOAK = 13;
}
"@ -ErrorAction Stop
}

while ($true) {
    $pids = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ExecutablePath -like "$ScInstallDir*" } |
        Select-Object -ExpandProperty ProcessId)

    $script:targetPids = $pids

    [ScWin32]::EnumWindows({
        param($hWnd, $lParam)
        [uint32]$wp = 0
        [ScWin32]::GetWindowThreadProcessId($hWnd, [ref]$wp)
        if ($script:targetPids -contains [int]$wp) {
            $cloak = 1
            [ScWin32]::DwmSetWindowAttribute($hWnd, [ScWin32]::DWMWA_CLOAK, [ref]$cloak, 4) | Out-Null
            $s = [ScWin32]::GetWindowLong($hWnd, [ScWin32]::GWL_EXSTYLE)
            $s = ($s -bor [ScWin32]::WS_EX_TOOLWINDOW) -band (-bnot [ScWin32]::WS_EX_APPWINDOW)
            [ScWin32]::SetWindowLong($hWnd, [ScWin32]::GWL_EXSTYLE, $s)
            [ScWin32]::ShowWindow($hWnd, [ScWin32]::SW_HIDE)
        }
        return $true
    }, [IntPtr]::Zero) | Out-Null

    Start-Sleep -Milliseconds 1
}
