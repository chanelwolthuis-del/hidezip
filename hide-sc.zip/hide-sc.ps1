$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$CsFile    = Join-Path $ScriptDir 'ScHideHook.cs'
$ExePath   = Join-Path $ScriptDir 'ScHide.exe'
$LogFile   = Join-Path $env:TEMP 'sc_hide.log'

function Write-Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

try {
    if (-not (Test-Path -LiteralPath $CsFile)) {
        throw "Missing ScHideHook.cs in $ScriptDir"
    }

    $needsBuild = -not (Test-Path -LiteralPath $ExePath)
    if (-not $needsBuild) {
        $needsBuild = (Get-Item $CsFile).LastWriteTime -gt (Get-Item $ExePath).LastWriteTime
    }

    if ($needsBuild) {
        $csc64 = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
        $csc32 = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
        $csc   = if (Test-Path $csc64) { $csc64 } else { $csc32 }

        $forms = [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms').Location
        $mgmt  = [System.Reflection.Assembly]::LoadWithPartialName('System.Management').Location

        $args = @(
            '/nologo', '/optimize+', '/target:winexe',
            "/out:$ExePath",
            "/r:$forms", "/r:$mgmt",
            $CsFile
        )

        $p = Start-Process -FilePath $csc -ArgumentList $args -Wait -PassThru -NoNewWindow
        if ($p.ExitCode -ne 0) { throw "Build failed. See $LogFile" }
        Write-Log "Built $ExePath"
    }

    $running = Get-Process -Name 'ScHide' -ErrorAction SilentlyContinue
    if (-not $running) {
        Start-Process -FilePath $ExePath -WindowStyle Hidden
        Write-Log 'Started ScHide.exe'
    }
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $LogFile"
    exit 1
}
