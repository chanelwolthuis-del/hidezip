$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$CsFile    = Join-Path $ScriptDir 'ScHideHook.cs'
$ExePath   = Join-Path $ScriptDir 'ScHide.exe'
$LogFile   = Join-Path $env:TEMP 'sc_hide.log'
$BatFile   = Join-Path $ScriptDir 'hide-sc.bat'

function Write-Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

try {
    if (Test-Path -LiteralPath $BatFile) {
        $p = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', "`"$BatFile`"" -Wait -PassThru -NoNewWindow
        if ($p.ExitCode -ne 0) { throw "hide-sc.bat failed with exit code $($p.ExitCode)" }
        Write-Log 'Started via hide-sc.bat'
        exit 0
    }

    if (-not (Test-Path -LiteralPath $CsFile)) {
        throw "Missing ScHideHook.cs in $ScriptDir"
    }

    $needsBuild = -not (Test-Path -LiteralPath $ExePath)
    if (-not $needsBuild) {
        $needsBuild = (Get-Item $CsFile).LastWriteTime -gt (Get-Item $ExePath).LastWriteTime
    }

    if ($needsBuild) {
        $csc64 = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
        $csc32 = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
        $csc   = if (Test-Path $csc64) { $csc64 } else { $csc32 }

        $args = @(
            '/nologo', '/optimize+', '/target:winexe',
            "/out:$ExePath",
            '/r:System.Windows.Forms.dll',
            '/r:System.Management.dll',
            $CsFile
        )

        $p = Start-Process -FilePath $csc -ArgumentList $args -Wait -PassThru -NoNewWindow
        if ($p.ExitCode -ne 0) { throw "Build failed. See $LogFile" }
        Write-Log "Built $ExePath"
    }

    $running = Get-Process -Name 'ScHide' -ErrorAction SilentlyContinue
    if (-not $running) {
        Start-Process -FilePath $ExePath -WindowStyle Hidden
        Write-Log 'Started ScHide.exe'
    }
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $LogFile"
    exit 1
}
