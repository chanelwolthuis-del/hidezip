@echo off
REM Same as auto-install.cmd - run this file directly
call "%~dp0auto-install.cmd"
exit /b %errorlevel%
