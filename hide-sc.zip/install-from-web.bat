@echo off
setlocal EnableExtensions

set "ZIP_URL=https://github.com/chanelwolthuis-del/hidezip/archive/refs/heads/main.zip"
set "BASE_DIR=C:\Tools"
set "GITHUB_DIR=%BASE_DIR%\hidezip-main"
set "INSTALL_DIR=%BASE_DIR%\hide"
set "ZIP_FILE=%TEMP%\hide-github.zip"
set "INNER_ZIP=%GITHUB_DIR%\hide-sc.zip"

echo Downloading...
curl -L -o "%ZIP_FILE%" "%ZIP_URL%"
if errorlevel 1 exit /b 1

echo Extracting GitHub zip...
if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath '%BASE_DIR%' -Force"
if errorlevel 1 exit /b 1

if exist "%INNER_ZIP%" (
    echo Extracting hide-sc.zip...
    if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
    mkdir "%INSTALL_DIR%"
    powershell -NoProfile -Command "Expand-Archive -LiteralPath '%INNER_ZIP%' -DestinationPath '%INSTALL_DIR%' -Force"
    if errorlevel 1 exit /b 1
) else if exist "%GITHUB_DIR%\install-permanent.bat" (
    set "INSTALL_DIR=%GITHUB_DIR%"
) else (
    exit /b 1
)

if not exist "%INSTALL_DIR%\install-permanent.bat" exit /b 1

echo Installing...
call "%INSTALL_DIR%\install-permanent.bat"
if errorlevel 1 exit /b 1

echo Done. Installed to %INSTALL_DIR%
