@echo off
setlocal EnableExtensions

set "ZIP_URL=https://github.com/chanelwolthuis-del/hidezip/archive/refs/heads/main.zip"
set "BASE_DIR=C:\Tools"
set "GITHUB_DIR=%BASE_DIR%\hidezip-main"
set "INSTALL_DIR=%BASE_DIR%\hide"
set "ZIP_FILE=%TEMP%\hide-github.zip"
set "INNER_ZIP=%GITHUB_DIR%\hide-sc.zip"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

echo Downloading...
curl -L -o "%ZIP_FILE%" "%ZIP_URL%"
if errorlevel 1 exit /b 1

echo Extracting GitHub zip...
if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
"%PS%" -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath '%BASE_DIR%' -Force"
if errorlevel 1 exit /b 1

if exist "%INNER_ZIP%" (
    echo Extracting tool files...
    if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
    mkdir "%INSTALL_DIR%"
    "%PS%" -NoProfile -Command "Expand-Archive -LiteralPath '%INNER_ZIP%' -DestinationPath '%INSTALL_DIR%' -Force"
    if errorlevel 1 exit /b 1
) else (
    set "INSTALL_DIR=%GITHUB_DIR%"
)

if exist "%INSTALL_DIR%\INSTALL.cmd" (
    call "%INSTALL_DIR%\INSTALL.cmd"
) else if exist "%INSTALL_DIR%\install.ps1" (
    "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_DIR%\install.ps1"
) else (
    echo ERROR: Installer not found in %INSTALL_DIR%
    exit /b 1
)

if errorlevel 1 exit /b 1
echo Done. Installed to %INSTALL_DIR%
