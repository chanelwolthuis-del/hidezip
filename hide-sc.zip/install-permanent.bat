@echo off
cd /d "%~dp0"

echo Building and starting...
call "%~dp0hide-sc.bat"
if errorlevel 1 exit /b 1

if not exist "%~dp0ScHide.exe" (
    echo ERROR: ScHide.exe not built.
    exit /b 1
)

echo Installing at login...
schtasks /Delete /TN "HideScreenConnectUI" /F >nul 2>&1
schtasks /Create /TN "HideScreenConnectUI" /TR "cmd /c \"\"%~dp0run.bat\"\"" /SC ONLOGON /F
if errorlevel 1 exit /b 1

echo Done. Runs at every login.
exit /b 0
