$TaskName  = 'HideScreenConnectUI'
$ScriptDir = $PSScriptRoot
$PsScript  = Join-Path $ScriptDir 'hide-sc.ps1'
$ExePath   = Join-Path $ScriptDir 'ScHide.exe'

if (-not (Test-Path $PsScript)) {
    Write-Host "ERROR: hide-sc.ps1 not found" -ForegroundColor Red
    exit 1
}

# Build exe first
powershell.exe -NoProfile -ExecutionPolicy Bypass -File $PsScript
if (-not (Test-Path $ExePath)) {
    Write-Host "ERROR: ScHide.exe was not built" -ForegroundColor Red
    exit 1
}

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

$Argument = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PsScript`""

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action (New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $Argument) `
    -Trigger (New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME) `
    -Settings (New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)) `
    -Description 'Zero-flash ScreenConnect UI hider' `
    -Force | Out-Null

Write-Host ""
Write-Host "Installed permanently (zero-flash)." -ForegroundColor Green
Write-Host "  Runs at every login"
Write-Host "  Exe: $ExePath"
Write-Host ""
Write-Host "To remove: uninstall-permanent.ps1"
