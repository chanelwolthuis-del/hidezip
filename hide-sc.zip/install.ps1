# ScreenConnect Hider - Full installer (run with: powershell -ExecutionPolicy Bypass -File install.ps1)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$CsFile    = Join-Path $ScriptDir 'ScHideHook.cs'
$ExePath   = Join-Path $ScriptDir 'ScHide.exe'
$TaskName  = 'HideScreenConnectUI'
$LogFile   = Join-Path $env:TEMP 'sc_hide.log'

function Write-Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

try {
    if (-not (Test-Path -LiteralPath $CsFile)) {
        throw "ScHideHook.cs not found in $ScriptDir"
    }

    $csc64 = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
    $csc32 = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
    $csc   = if (Test-Path $csc64) { $csc64 } else { $csc32 }

    if (-not (Test-Path $csc)) { throw 'C# compiler (csc.exe) not found.' }

    $needsBuild = -not (Test-Path $ExePath)
    if (-not $needsBuild) {
        $needsBuild = (Get-Item $CsFile).LastWriteTime -gt (Get-Item $ExePath).LastWriteTime
    }

    if ($needsBuild) {
        Write-Host 'Building ScHide.exe...'
        $buildArgs = @(
            '/nologo', '/optimize+', '/target:winexe',
            "/out:$ExePath",
            '/r:System.Windows.Forms.dll',
            '/r:System.Management.dll',
            $CsFile
        )
        $p = Start-Process -FilePath $csc -ArgumentList $buildArgs -Wait -PassThru -NoNewWindow
        if ($p.ExitCode -ne 0) { throw "Build failed (exit $($p.ExitCode))" }
        Write-Log "Built $ExePath"
    }

    Get-Process -Name 'ScHide' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Process -FilePath $ExePath -WindowStyle Hidden
    Write-Log 'Started ScHide.exe'

    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

    $runBat = Join-Path $ScriptDir 'run.bat'
    $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"`"$runBat`"`""
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)

    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings `
        -Description 'Hide ScreenConnect UI' -Force | Out-Null

    Write-Host ''
    Write-Host 'SUCCESS - Installed permanently.' -ForegroundColor Green
    Write-Host "  Folder : $ScriptDir"
    Write-Host "  Runs at: every Windows login"
    Write-Host ''
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log : $LogFile"
    exit 1
}
