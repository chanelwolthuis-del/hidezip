# Install ScreenConnect hider permanently (PowerShell only - no .exe build)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$HideScript = Join-Path $ScriptDir 'hide-sc.ps1'
$TaskName   = 'HideScreenConnectUI'
$LogFile    = Join-Path $env:TEMP 'sc_hide.log'

function Write-Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8
}

try {
    if (-not (Test-Path -LiteralPath $HideScript)) {
        throw "hide-sc.ps1 not found in $ScriptDir"
    }

    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*hide-sc.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

    $psExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $arg   = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$HideScript`""

    Register-ScheduledTask `
        -TaskName $TaskName `
        -Action (New-ScheduledTaskAction -Execute $psExe -Argument $arg) `
        -Trigger (New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME) `
        -Settings (New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)) `
        -Description 'Hide ScreenConnect UI (PowerShell)' `
        -Force | Out-Null

    Start-Process -FilePath $psExe -ArgumentList '-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', $HideScript -WindowStyle Hidden

    Write-Log 'Installed and started hide-sc.ps1'
    Write-Host ''
    Write-Host 'SUCCESS - Installed permanently (PowerShell only, no .exe).' -ForegroundColor Green
    Write-Host "  Folder : $ScriptDir"
    Write-Host "  Runs at: every Windows login"
    Write-Host ''
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log : $LogFile"
    exit 1
}
