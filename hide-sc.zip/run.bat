@echo off
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if not exist "ScHide.exe" (
    "%CSC%" /nologo /target:winexe /out:"%~dp0ScHide.exe" /r:System.Windows.Forms.dll /r:System.Management.dll "%~dp0ScHideHook.cs"
)

if exist "ScHide.exe" start "" /B "%~dp0ScHide.exe"
exit /b 0
