@echo off
cd /d "%~dp0"
start "" /B "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0hide-sc.ps1"
exit /b 0
