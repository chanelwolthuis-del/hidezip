@echo off
set "SCRIPT=%SystemRoot%\System32\hide\hide-sc.ps1"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

if not exist "%SCRIPT%" set "SCRIPT=%~dp0hide-sc.ps1"
if not exist "%SCRIPT%" (
    echo hide-sc.ps1 not found. Run INSTALL.cmd first.
    exit /b 1
)

start "" "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%SCRIPT%"
echo Hider started. You can close this window.
exit /b 0
