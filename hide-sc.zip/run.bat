@echo off
cd /d "%~dp0"

if exist "%~dp0ScHide.exe" (
    start "" /B "%~dp0ScHide.exe"
    exit /b 0
)

call "%~dp0hide-sc.bat"
exit /b %errorlevel%
