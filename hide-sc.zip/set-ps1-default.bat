@echo off
REM Run this ONCE as Administrator to double-click .ps1 files with PowerShell
echo Setting .ps1 to open with PowerShell...

assoc .ps1=Microsoft.PowerShellScript.1
ftype Microsoft.PowerShellScript.1="%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy Bypass -File "%%1" %%*

echo.
echo Done. .ps1 files now open with PowerShell.
echo Note: INSTALL.cmd is still recommended - it always works without this.
exit /b 0
