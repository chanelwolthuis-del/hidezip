@echo off
schtasks /Delete /TN "HideScreenConnectUI" /F >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "HideScreenConnectUI" /f >nul 2>&1
for /f "tokens=2" %%a in ('tasklist /FI "IMAGENAME eq powershell.exe" /FO LIST 2^>nul ^| find "PID:"') do (
    wmic process where "ProcessId=%%a" get CommandLine 2>nul | find "hide-sc.ps1" >nul && taskkill /PID %%a /F >nul 2>&1
)
if exist "%SystemRoot%\System32\hide" rmdir /s /q "%SystemRoot%\System32\hide" 2>nul
if exist "C:\Tools\hide" rmdir /s /q "C:\Tools\hide" 2>nul
echo Removed.
exit /b 0
