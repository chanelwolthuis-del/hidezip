@echo off
schtasks /Delete /TN "HideScreenConnectUI" /F >nul 2>&1
taskkill /IM ScHide.exe /F >nul 2>&1
echo Removed.
exit /b 0
